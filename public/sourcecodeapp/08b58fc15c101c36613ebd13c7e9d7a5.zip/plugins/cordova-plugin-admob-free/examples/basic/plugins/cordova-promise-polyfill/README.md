# Promise polyfill for Cordova

This is a polyfill of the ES6 Promise for Cordova.

## Usage

Add dependency to your plugin's `plugin.xml`:

```xml
<dependency id="cordova-promise-polyfill"></dependency>
```
