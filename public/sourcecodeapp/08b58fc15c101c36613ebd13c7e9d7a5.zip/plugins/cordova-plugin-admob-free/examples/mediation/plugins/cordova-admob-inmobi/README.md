# Cordova AdMob Mediation Plugin for InMobi

## Installation

```sh
cordova plugin add cordova-admob-inmobi --save
```
