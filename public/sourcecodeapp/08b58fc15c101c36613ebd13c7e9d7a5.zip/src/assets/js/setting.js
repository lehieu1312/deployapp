var wordpress_url = "http://cellstore.taydomobile.com";
var onesignal_app_id = "9dd05ff0-a03d-41e5-a1c7-df0da932b3a7";
var wordpress_per_page = 10;
var post_per_page = 4;
var request_timeout = 15000; // milliseconds 
var notice_timeout = 2000; // milliseconds
var slide_time = 3000; // milliseconds
var hide_sale = true;
