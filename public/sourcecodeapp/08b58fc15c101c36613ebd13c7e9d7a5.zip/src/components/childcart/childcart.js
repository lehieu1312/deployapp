var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';
var ChildcartComponent = (function () {
    function ChildcartComponent(storage, navCtrl) {
        this.storage = storage;
        this.navCtrl = navCtrl;
        this.cart = {};
        this.update();
    }
    ChildcartComponent.prototype.update = function () {
        var _this = this;
        this.storage.get('cart').then(function (val) {
            _this.cart = { count: 0 };
            for (var key in val) {
                var product = val[key];
                _this.cart["count"] += product.quantity;
            }
        });
    };
    return ChildcartComponent;
}());
__decorate([
    Input(),
    __metadata("design:type", String)
], ChildcartComponent.prototype, "icon", void 0);
ChildcartComponent = __decorate([
    Component({
        selector: 'childcart',
        templateUrl: 'childcart.html'
    }),
    __metadata("design:paramtypes", [Storage, NavController])
], ChildcartComponent);
export { ChildcartComponent };
//# sourceMappingURL=childcart.js.map