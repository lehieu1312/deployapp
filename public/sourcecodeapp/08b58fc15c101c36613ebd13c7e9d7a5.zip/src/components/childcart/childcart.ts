import { Component} from '@angular/core';
import { NavController } from 'ionic-angular';

import { Storage } from '@ionic/storage';

@Component({
  selector: 'childcart',
  templateUrl: 'childcart.html'
})
export class ChildcartComponent {
  cart:Object = {};

  constructor(public storage: Storage, public navCtrl: NavController) {
    this.update();
  }
  update(){
    this.storage.get('cart').then((val) =>{
            this.cart = {count:0};
            for(var key in val){
                let product = val[key];
                this.cart["count"] += product.quantity;
            }
        });
    }

}
