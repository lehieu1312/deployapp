import { Component, ViewChild} from '@angular/core';
import { NavController} from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { Keyboard } from '@ionic-native/keyboard';

// Custom
import { CartPage } from '../../pages/cart/cart';
// import { HomePage } from '../../pages/home/home';
import { AccountPage } from '../../pages/account/account';
import { SettingPage } from '../../pages/setting/setting';
@Component({
  selector: 'footer',
  templateUrl: 'footer.html'
})
export class Footer {
	CartPage = CartPage;
	AccountPage = AccountPage;
	SettingPage = SettingPage;
  	active: any;
  	@ViewChild('cart') buttonCart;
      // cart:Object = {};
    cart_total: number;
    keyboard_show = false;
    constructor(public navCtrl: NavController, public storage: Storage, public keyboard: Keyboard) {
        // this.cart = {count:0};
        this.update_footer();
    }

    ngOnInit(){
        this.keyboard.onKeyboardShow().subscribe(() => {
            this.keyboard_show = true;
        });
        this.keyboard.onKeyboardHide().subscribe(() => {
            this.keyboard_show = false;
        });
        this.active = this.navCtrl.getActive().component.name;
    }
    
	goto(page:string){
		// this.update_footer();
		if (this.active != page) {
			if (page == "HomePage") {
				this.navCtrl.popToRoot();
			} else {
				let previous = this.navCtrl.getPrevious();
				if (previous && previous.component.name == page) this.navCtrl.pop();
				else this.navCtrl.push(this[page], {cart:this.cart_total});
			}
		}
    }
    
    updateRoot() {
        this.active = "HomePage";
    }

	update_footer(){
		this.storage.get('cart').then((val) =>{
            let tmp = 0;
        	for(var key in val){
                let product = val[key];
                tmp += product.quantity;
            }
            this.cart_total = tmp;
        });
        
	}
}
