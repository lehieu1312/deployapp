import { Component, ViewChild } from '@angular/core';
import { AlertController, NavController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http';

// Custom
import { Storage } from '@ionic/storage';
import { TranslateService } from 'ng2-translate';
import { StorageMulti } from '../../service/storage-multi.service';
import { Config } from '../../service/config.service';

// Page
import { SigninPage } from '../signin/signin';
import { OrderPage } from '../order/order';
import { FavoritePage } from '../favorite/favorite';
import { ProfilePage } from '../profile/profile';
import { CartPage } from '../cart/cart';
import { SettingPage } from '../setting/setting';

@Component({
  selector: 'page-account',
  templateUrl: 'account.html',
  providers: [StorageMulti]
})
export class AccountPage {
    @ViewChild('footer') buttonFooter;
	Signin = SigninPage;
	Profile = ProfilePage;
	Order = OrderPage;
    Favorite = FavoritePage;
    SettingPage = SettingPage;
    CartPage = CartPage;
    isCache:boolean = false; 
    isLogin:boolean; 
    data:any = {};

    constructor(
        public storage: Storage,
        public navCtrl: NavController,
        public navParams: NavParams,
        public storageMulti: StorageMulti,
        public alertCtrl: AlertController,
        public translate: TranslateService,
        public http: Http,
        public config: Config
    ){
        this.getData();
    }

    ionViewDidEnter() {
        this.buttonFooter.update_footer();

        if (this.isCache) this.getData();
        else this.isCache = true;
    }

	getData(){
		this.storageMulti.get(['login', 'user']).then(val =>{
			if (val){
				if(val["login"] && val["login"]["token"]){
					this.data["login"] = val["login"];
					this.isLogin = true;

				}
				if(val["user"]) this.data["user"] = val["user"];
			}
		});
	}

	signOut(){
		this.translate.get('account.signout').subscribe(trans => {
			let confirm = this.alertCtrl.create({
				title: trans["app_name"],
				message: trans["message"],
				cssClass: 'alert-no-title title alert-blue-btn cancel',
				buttons: [
					{
                        text:trans["no"]
					},
					{
						text:trans["yes"],
						handler:() =>{
                            this.storage.remove('user');
							this.storage.remove('login').then(() => {
								this.isLogin = false;
								this.navCtrl.popToRoot();
							});
						}
					}
				]

			});
			confirm.present();
		});
    }
    
	onSwipeContent(e){
		if(e['deltaX'] < -150 || e['deltaX'] > 150){
			if(e['deltaX'] < 0) this.navCtrl.push(this.SettingPage);
			else this.navCtrl.push(this.CartPage);
		}
	}
}