import { Component } from '@angular/core';
import { NavController, NavParams, ModalController} from 'ionic-angular';

import { Core } from '../../service/core.service';
import { Http } from '@angular/http';
import { TranslateService } from 'ng2-translate';

import { RatingPage } from '../rating/rating';
import { SigninPage } from '../signin/signin';
import { DetailPage } from '../detail/detail';

declare var wordpress_url:string;

@Component({
  selector: 'page-comment',
  templateUrl: 'comment.html',
  providers: [Core]
})

export class CommentPage {
	RatingPage=RatingPage;
    SigninPage=SigninPage;
    DetailPage = DetailPage;
	comments: Object[] = [];
	id:number;
	login:Object;
    user:Object;
    trans: any;

  constructor(
  	public navCtrl: NavController,
  	public navParams: NavParams,
  	public core:Core,
  	public http:Http,
    public modalCtrl:ModalController,
    public translate: TranslateService
  	) {
        translate.get('detail.comment_process').subscribe(trans => this.trans = trans);
        this.id = navParams.get('id');
        this.getCommentProduct(); 
    }

    getCommentProduct(){
        this.core.showLoading();
        this.http.get(wordpress_url + '/wp-json/wooconnector/product/getproduct/' +this.id)
            .subscribe(res => {
                let tmp = res.json()['wooconnector_reviews'];
                if(tmp && JSON.stringify(tmp) == JSON.stringify(this.comments)) {
                    console.log('into 1');
                    this.core.showToastBottom(this.trans);
                } else if (tmp && JSON.stringify(tmp) != JSON.stringify(this.comments)) {
                    this.comments = tmp;
                }
                this.core.hideLoading();
            }, err => {
                this.core.hideLoading();
                console.log(err);
            }
        );
    }

	showRating(){
        let html = document.querySelector('html');
        html.classList.add('rating');
        let modal = this.modalCtrl.create(RatingPage, {id:this.id});
        modal.onDidDismiss(reload => {
            html.classList.remove('rating');
            if(reload) {
                this.getCommentProduct();
            }
        });
        modal.present();
    }

}
