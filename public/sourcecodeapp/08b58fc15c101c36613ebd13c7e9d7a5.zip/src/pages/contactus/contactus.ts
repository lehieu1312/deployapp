import { Component } from '@angular/core';
import { Platform, NavParams } from 'ionic-angular';
import { Http} from '@angular/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Config } from '../../service/config.service';
import { CallNumber } from '@ionic-native/call-number';
import { Geolocation } from '@ionic-native/geolocation';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import { Diagnostic } from '@ionic-native/diagnostic';
import { LinkProvider } from '../../providers/link/link';
//custom
import { CoreValidator } from '../../validator/core';
import { Storage } from '@ionic/storage';
import { Core } from '../../service/core.service';
import { TranslateService } from 'ng2-translate';
declare var wordpress_url;
declare var google;
@Component({
  selector: 'page-contactus',
  templateUrl: 'contactus.html',
  providers: [Core, CallNumber, Geolocation, LocationAccuracy, Diagnostic]
})
export class ContactusPage {
	check:boolean = true;
  checkselect: any;
  formContact: FormGroup;
  trans:Object;
  open_target_blank: boolean;
  submitAttempt = false;
  lat = -34.9290;
  lng = 138.6010;
  distance_km: any;
  textStatic: Object ={};
  
  constructor(
        public navParams: NavParams,
        public formBuilder: FormBuilder,
        public http: Http,
        public storage: Storage,
        public platform: Platform,
        public translate: TranslateService,
        public config: Config,
        public core : Core,
        public callNumber: CallNumber,
        public geolocation: Geolocation,
        public LocationAccuracy: LocationAccuracy,
        public Diagnostic: Diagnostic,    
        public linkProvider: LinkProvider
    ) {
        this.formContact = formBuilder.group({
          name: ['', CoreValidator.required],
          email: ['', Validators.compose([CoreValidator.required, CoreValidator.isEmail])],
          subject: ['', CoreValidator.required],
          message:['', CoreValidator.required]
      });
      translate.get('contact').subscribe(trans => this.trans = trans);
      this.textStatic = config['text_static'];
      if(config['text_static']['cellstore_latitude_gmap']) {
        this.lat = config['text_static']['cellstore_latitude_gmap'];
      }
      if(config['text_static']['cellstore_longtitude_gmap']) {
        this.lng = config['text_static']['cellstore_longtitude_gmap'];
      }
    }

    ionViewDidEnter() {
        let scrollMap = false;
        scrollMap = this.navParams.get("scrollMap");

        if( scrollMap == true) {
          this.scrollToView('contact-us-map');
        }
    }

  findDistance() {
    this.LocationAccuracy.canRequest().then((can: boolean) => {
        if (can || this.platform.is('ios')) {
            this.core.showLoading();
            this.LocationAccuracy.request(this.LocationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(() => {
                this.geolocation.getCurrentPosition({enableHighAccuracy: true}).then((resp) => {
                    console.log(resp.coords);
                    let distance = google.maps.geometry.spherical
                        .computeDistanceBetween(new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude), 
                            new google.maps.LatLng(this.lat, this.lng));   
                    this.distance_km = (distance/1000).toFixed(2);
                    this.core.hideLoading();    
                }).catch((error) => {
                    console.log('Error getting location', error);
                    this.core.hideLoading();    
                });
            }, err => {
                this.core.hideLoading(),
                console.log(err)
            }
            );
        } else {
            this.Diagnostic.requestLocationAuthorization('always').then(res => {
                if (res == "GRANTED" || res == "authorized_when_in_use"
                    || res == "authorized") this.findDistance();
            });
        }
    },
        err  => console.log(err)
    );
  }

  ionViewDidLoad() {
    this.loadMap();
    this.findDistance();
  }


  loadMap() {
    let element = document.getElementById('map_canvas');
    let latLng = new google.maps.LatLng(this.lat, this.lng);
    
    let mapOptions = {
      center: latLng,
      zoom: 12,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }

    let map = new google.maps.Map(element, mapOptions);
    let marker = new google.maps.Marker({
      title: this.textStatic['cellstore_contact_us_title'],
      position: latLng,
      map: map
    });
  }

  callNow(phone) {
    if(phone) {
        this.callNumber.callNumber(phone, true)
        .then(() => console.log('Launched dialer!'))
        .catch(() => console.log('Error launching dialer'));
    }
  }

    openLink(url: string) {
       this.linkProvider.openExternal(url);
    }

  scrollToView(element) {
    this.core.scrollToView(element);
  }

  send() {
    if(this.formContact.invalid) {
      this.submitAttempt = true;
    } else {
      this.core.showLoading();
      this.http.post(wordpress_url+'/wp-json/wooconnector/contactus/sendmail', this.formContact.value)
      .subscribe(res => {
        if (res.json()['result'] == 'success') {
          this.core.hideLoading();
          this.formContact.patchValue({subject: null});
          this.formContact.patchValue({message: null});
          this.core.showToastBottom(this.trans["success"]);
          this.submitAttempt = false;
        } else {
          this.core.hideLoading();
          this.core.showLoading(this.trans["error"]);
        }
      });
    }
  }

  showtime(){
    if (this.check) {
      this.check = false;
    } else {
      this.check = true;
    }
  }
}

