import { Component } from '@angular/core';
import { ViewController, NavParams, NavController } from 'ionic-angular';
import { Http, Headers } from '@angular/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

// Custom
import { Core } from '../../service/core.service';
import { Storage } from '@ionic/storage';
import { TranslateService } from 'ng2-translate';
import { CoreValidator } from '../../validator/core';

// Page
import { SigninPage } from '../signin/signin';
import { CommentPage } from '../comment/comment';

declare var wordpress_url;

@Component({
  selector: 'page-rating',
  templateUrl: 'rating.html',
  providers: [Core]
})
export class RatingPage {
    SigninPage = SigninPage;
    CommentPage = CommentPage;
	id:Number;
    ratingValue:Number = 0;
    emptyRating: boolean = false;
	login:Object = {}; user:Object = {};
    trans:Object;
    guest = true;
    formComment: FormGroup;
    submitAttempt = false;
    ready = false;

	constructor(
		public navCtrl: NavController,
		public viewCtrl: ViewController,
		public navParams: NavParams,
		public http:Http,
		public core:Core,
		public storage: Storage,
		public translate: TranslateService,
        public formBuilder: FormBuilder
		) {
            this.formComment = formBuilder.group({
                namecustomer: ['', CoreValidator.required],
                emailcustomer: ['', Validators.compose([CoreValidator.required, CoreValidator.isEmail])],
                comment: ['', CoreValidator.required]
            });  
			translate.get('rating').subscribe(trans => this.trans = trans);
			this.id = navParams.get("id");
            this.storage.get('login').then(login => { 
                if(login){
                    this.guest = false;
                    this.login = login;
                    this.storage.get('user').then(user => { 
                        this.user = user;
                        this.formComment.controls.namecustomer.setValue(this.user['display_name']);
                        this.formComment.controls.emailcustomer.setValue(this.user['user_email']);
                        this.ready = true;
                    })
                } else {
                    this.ready = true;
                }

                
            })
		}


		dismiss(reload:boolean = false){
			this.viewCtrl.dismiss(reload);
		}

        changeRating(value) {
            this.ratingValue = value;
            this.emptyRating = false;
        }

		rating(){
            this.submitAttempt = true;
            if(this.ratingValue == 0) {
                this.emptyRating = true;
            } 
            if(this.ratingValue != 0 && this.formComment.valid) {
                let cmt = this.formComment.value.comment.replace(/\r?\n/g, '&#13;&#10;');
                let params = this.formComment.value;
                params['comment'] = cmt;
                params['product'] = this.id;
                params['ratestar'] = this.ratingValue;
                let option:Object = {};
                if(this.login && this.login["token"]){
                    let headers = new Headers();
                    headers.set('Content-Type', 'application/json; charset=UTF-8');
                    headers.set('Authorization', 'Bearer '+this.login["token"]);
                    option['headers'] = headers
                }
                this.core.showLoading();
                this.http.post(wordpress_url+'/wp-json/wooconnector/product/postreviews', params, option)
                .subscribe(res => { 
                    this.core.hideLoading();
                    if(res.json()["result"] == "success") this.dismiss(true);
                }, err => {
                    this.core.hideLoading();
                    if(err.json()['message'] == "Expired token") {
                        this.core.showToastBottom(this.trans["expiredToken"]);
                        this.dismiss(false);
                    } else {
                        this.translate.get('errorMessage.undefined').subscribe(
                            trans => {
                                this.dismiss(false);
                                this.core.showToastBottom(trans);
                            }
                        );
                    }
                });
            }
			
		}

}
