import { Component } from '@angular/core';
import { NavController, AlertController, NavParams} from 'ionic-angular';
import { Http, Headers} from '@angular/http';
import { FormBuilder, FormGroup } from '@angular/forms';

// Custom
import { Core } from '../../service/core.service';
import { Storage } from '@ionic/storage';
import { TranslateService } from 'ng2-translate';
import { Config } from '../../service/config.service';

//Page
import { SignupPage } from '../signup/signup';
import { ForgotPage } from '../forgot/forgot';
import { HomePage } from '../home/home';
import { CoreValidator } from '../../validator/core';

declare var wordpress_url;

@Component({
  selector: 'page-signin',
  templateUrl: 'signin.html',
  providers: [Core]
})
export class SigninPage {
	wordpress_user:string = wordpress_url+'/wp-json/mobiconnector/user';
	SignupPage = SignupPage;
    ForgotPage = ForgotPage;
	HomePage = HomePage;
    formLogin: FormGroup;
    submitAttempt = false;
    wrong_pass_username = false;
	wrong:boolean;
	trans:Object = {};
	checkreturn:string;
    type:string = 'password'; check:boolean = false;

	constructor(
		public navCtrl: NavController,
		public formBuilder: FormBuilder,
		public http: Http,
		public core: Core,
		public storage: Storage,
		public alertCtrl: AlertController,
		public translate: TranslateService,
		public navParams : NavParams,
        public config: Config
		) {
		this.formLogin = formBuilder.group({
			username: ['', CoreValidator.required],
			password: ['', CoreValidator.required]
		});
		translate.get('login').subscribe(trans => { if(trans) this.trans = trans; });
        this.checkreturn = navParams.get('check');
	}
	login(){
        this.submitAttempt = true;
        if(!this.formLogin.invalid) {
            let params = this.core.objectToURLParams(this.formLogin.value);
            // params['lang'] = application_language;
            this.core.showLoading();
            let headers = new Headers();
            headers.set('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
            // headers.set('Cookie', 'qtrans_front_language=vi');
            this.http.post(wordpress_url + '/wp-json/mobiconnector/jwt/token', params,{
                headers: headers,
                withCredentials: true
            })
            .subscribe(
                res => {
                    let login = res.json();
                    login.username = this.formLogin.value.username;
                    let params = this.core.objectToURLParams({'username':login["username"]});
                    this.http.post(this.wordpress_user+'/get_info', params)
                    .subscribe(
                    user => {
                        this.core.hideLoading();
                        this.core.showToastBottom(this.trans["success"]);
                        this.storage.set('user', user.json()).then(() => {
                            this.storage.set('login', login).then(() => {
                                if(this.navParams.get('parent') == 'signup') {
                                    this.navCtrl.popToRoot();
                                } else {
                                    this.navCtrl.pop();
                                }  
                            });
                        });
                    })
                }, err => {
                    this.core.hideLoading();
                    if(err.json()['code'] == "[jwt_auth] incorrect_password" 
                        || err.json()['code'] == "[jwt_auth] invalid_username") {
                        this.wrong_pass_username = true;
                    } else {
                        this.translate.get('errorMessage.undefined').subscribe(trans => { 
                            this.core.showToastBottom(trans);
                        });
                    }
                }
            );
        }
	}
	show_hide_Pass(){
		if (this.check){
			this.check = false;
			this.type = 'password';
		} else {
			this.check = true;
			this.type = 'text';
		}
	}

    autoFocus(target) { 
        this.core.autoFocus(target);
    }
}
