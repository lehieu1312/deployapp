import { Component } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';
import { DetailcategoryPage } from '../detailcategory/detailcategory';
/*
  Generated class for the Sortpopup page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-sortpopup',
  templateUrl: 'sortpopup.html'
})
export class SortpopupPage {
	hidden:boolean = false;
	DetailcategoryPage = DetailcategoryPage;
	sort:string;
	filter:Object = {grid:true, open:null, value:{}};
    constructor(
        public navCtrl: NavController,
        public navParams: NavParams,
        public viewCtrl: ViewController
        ) {
        this.sort = navParams.get('sort');
        console.log(this.sort);
    }
  
    close(){
        if(this.sort) {   
            this.viewCtrl.dismiss(this.sort);
        } else {
            this.viewCtrl.dismiss(false);
        }
    }

    click(){
        this.viewCtrl.dismiss(this.sort);
    }
}
