import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Config } from '../../service/config.service';

@Component({
  selector: 'page-term',
  templateUrl: 'term.html'
})
export class TermPage {
    public static_text;
    
    constructor(public navCtrl: NavController, 
    	public navParams: NavParams,  
    	public config: Config) {
        this.static_text = config['text_static'];
    }
}
