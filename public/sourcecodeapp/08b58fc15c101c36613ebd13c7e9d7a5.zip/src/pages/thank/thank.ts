import { Component } from '@angular/core';
import { NavController, NavParams, Platform} from 'ionic-angular';
import { Storage } from '@ionic/storage';

// Page
import { OrderdetailPage } from '../orderdetail/orderdetail';

@Component({
  selector: 'page-thank',
  templateUrl: 'thank.html'
})
export class ThankPage {
    OrderdetailPage = OrderdetailPage;
    id: any;
	isLogin = false;
    bank_payment = false;
    ready = false;
	
	constructor(
        public navCtrl: NavController, 
        public navParams: NavParams, 
        public platform: Platform,
        public storage: Storage ) {
        this.id = navParams.get('id');
        if(navParams.get('payment') == 'bacs'){
            this.bank_payment = true;
        };

        storage.get('login').then(val => {
            if (val && val["token"]) {
                this.isLogin = true;
            } 
            this.ready = true;
        });
    }
    
    ngOnInit() {
         this.platform.ready().then(() => {
             this.platform.registerBackButtonAction(() => {
                let active = this.navCtrl.getActive().component.name;;
                if(active == "ThankPage") {
                    this.navCtrl.popToRoot();
                } else {
                    this.navCtrl.pop();
                }
            });
         })
        
    }

	backtohome(){
		this.navCtrl.popToRoot();
	}

}
