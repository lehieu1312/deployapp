var wordpress_url = "WORDPRESS_URL";
var onesignal_app_id = "ONESIGNAL_APP_ID";
var wordpress_per_page = WORDPRESS_PER_PAGE;
var post_per_page = POST_PER_PAGE;
var request_timeout = REQUEST_TIMEOUT;
var notice_timeout = NOTICE_TIMEOUT;
var slide_time = SLIDE_TIME;
var hide_sale = HIDE_SALE;
