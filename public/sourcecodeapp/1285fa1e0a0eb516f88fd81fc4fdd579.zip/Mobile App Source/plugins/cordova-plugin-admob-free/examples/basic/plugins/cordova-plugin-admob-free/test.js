console.log('Can only be used with Cordova.')
