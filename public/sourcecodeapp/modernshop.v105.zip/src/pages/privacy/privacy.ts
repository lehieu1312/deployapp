import { Component } from '@angular/core';

@Component({
	selector: 'page-privacy',
	templateUrl: 'privacy.html'
})
export class PrivacyPage {
	constructor() {}
}