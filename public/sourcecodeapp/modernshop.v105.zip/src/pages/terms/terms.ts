import { Component } from '@angular/core';

@Component({
	selector: 'page-terms',
	templateUrl: 'terms.html'
})
export class TermsPage {
	constructor() {}
}